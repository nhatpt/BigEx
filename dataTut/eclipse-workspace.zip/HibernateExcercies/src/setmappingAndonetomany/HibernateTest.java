package setmappingAndonetomany;

import java.util.HashSet;

public class HibernateTest {
	public static void main(String args[]) {
		
		HashSet<Subject> subjectSet1 = new HashSet<Subject>();
		subjectSet1.add(new Subject("Data Structure"));
		subjectSet1.add(new Subject("Operting System"));

		HashSet<Subject> subjectSet2 = new HashSet<Subject>();
		subjectSet2.add(new Subject("Compier"));
		subjectSet2.add(new Subject("Networking"));
		subjectSet2.add(new Subject("DBMS"));

		// Create the student object.
		Student student1 = new Student("Harish", "Kansal", "MCA final", "MCA/07/72", 27);
		Student student2 = new Student("Sunil", "Kumar", "MCA final", "MCA/07/73", 32);

		student1.setSubjects(subjectSet1);
		student2.setSubjects(subjectSet2);

		StudentDBOperations obj = new StudentDBOperations();
		// insert student object.
		obj.addStudent(student1);
		obj.addStudent(student2);

		// show all student object.
		obj.showAllStudentDetails();

	}
}
