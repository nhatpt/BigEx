package annotation;

import annotation.Connector.Connector;

public class App {
	public static void main(String[] args) {
		Connector con = new Connector();
		con.showAllStudentDetails();
	}
}
