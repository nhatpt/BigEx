package com.polymorphism;

interface Person {
	String getDescription();
}
