package com.polymorphism;

public class PersonViewer {
	public void view(Person person) {
		System.out.println(person.getDescription());
	}
}
