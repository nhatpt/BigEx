package com.polymorphism;

public class Student implements Person{
	String name;
	String email;
	String grade;
	
	public Student(String _name, String _email, String _grade) {
		this.name = _name;
		this.email = _email;
		this.grade = _grade;
	}
	
	public String getGrade() {
		return grade;
	}
	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return this.name + " " + getGrade() + " grade student.";
	}
	
}
