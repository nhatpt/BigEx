package com.polymorphism;

public class Lecturer implements Person{
	String name;
	String subject;
	public Lecturer(String _name, String _sub) {
		this.name = _name;
		this.subject = _sub;
	}
	
	public String getSubject() {
		return this.subject;
	}
	
	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return this.name + " teaches " + getSubject();
	}
	
	
}
