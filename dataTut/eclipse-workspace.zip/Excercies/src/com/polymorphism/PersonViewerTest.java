package com.polymorphism;

public class PersonViewerTest {
	public static void main(String[] args) {
		PersonViewSubclass pvs = new PersonViewSubclass();
		//print out
		Student st2 = new Student("Noname", "example@gmail.com", "TOIEC");
		Lecturer lt2 = new Lecturer("Proje", "Graphics");
		Employee ep2 = new Employee("LQQ", "TQAM");
		pvs.viewPerson(st2);
		pvs.viewPerson(lt2);
		pvs.viewPerson(ep2);
	}
}
