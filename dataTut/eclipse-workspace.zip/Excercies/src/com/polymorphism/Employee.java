package com.polymorphism;

public class Employee implements Person{
	String name;
	String departmentName;
	
	public Employee(String _name, String _departmentName) {
		this.name = _name;
		this.departmentName = _departmentName;
	}
	public String getDepartment() {
		return this.departmentName;
	}
	@Override
	public String getDescription() {
		
		return this.name + " work at " + getDepartment();
	}
}
