package com.polymorphism;

public class PersonViewSubclass extends PersonViewer {
	@Override
	public void view(Person person) {
		if (person instanceof Employee) {
			Employee emp = (Employee) person;
			System.out.println(emp.getDescription());
		} else if (person instanceof Lecturer) {
			Lecturer lt = (Lecturer) person;
			System.out.println(lt.getDescription());
		} else if (person instanceof Student) {
			Student st = (Student) person;
			System.out.println(st.getDescription());
		} else {
			System.out.println("Error!!");
		}
	}

	void viewPerson(Employee emp) {
		System.out.println(emp.getDescription());
	}

	void viewPerson(Lecturer lec) {
		System.out.println(lec.getDescription());
	}

	void viewPerson(Student st) {
		System.out.println(st.getDescription());
	}
}
