package com.polymorphism;

public class EnhancedPersonViewer {
	public static void main(String[] args) {
		PersonViewer pv = new PersonViewer();
		Person st = new Student("OTA", "access@gmail.com", "Quota");
		Person lt = new Lecturer("XTAs", "DesignUI");
		Person em = new Employee("ChiAX", "WeSXa");
		
		//print out
		pv.view(st);
		pv.view(lt);
		pv.view(em);
	}
}
