package com.abstractclass;

public class SecondChild  extends AbstractParent{
	@Override
	public String generateString() {
		return "Suitable String";
	}
	
	public static void main(String[] args) {
		SecondChild sc = new SecondChild();
		System.out.println(sc.getMessage());
	}
	
	//SecondChild have not getMessage() method but still call. Because:
	//	1. getMessage() is a public class and SecondChild extends AbstractParent so SecondChild can use it
	//	2. getMessage() return generateString() value. In SecondChild have overrided generateString() 
	// and return a value. This value will get to getMessage(). So when we print this will that.
	
	
}
