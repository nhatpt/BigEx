package com.abstractclass;

public abstract class AbstractParent {
	public String getMessage() {
		return generateString();
	}
	
	protected abstract String generateString();
}
