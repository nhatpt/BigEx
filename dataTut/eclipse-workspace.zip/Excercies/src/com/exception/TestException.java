package com.exception;

public class TestException {

	public int test1(int a, int b) {
		int res = 0;
		try {
			res =  test2(a,b);
		} catch (ArithmeticException e) {
			System.out.println("Test 1 error:"+ e.getMessage());
		}
		finally {
			System.out.println("Finally Always run.");
		}
		return res;
	}
	
	public int test2(int a, int b) throws NumberFormatException {
		return a/b;
	}
	
	public static void main(String[] args) {	
		TestException te = new TestException();
		int res = te.test1(1, 0);
		System.out.println(res);
		
	}
}
