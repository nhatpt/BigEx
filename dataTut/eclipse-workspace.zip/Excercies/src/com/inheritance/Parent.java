package com.inheritance;

public class Parent {
	protected String myMessage;
	Parent() {
		System.out.println("Parent default constructor");
	}
	
	Parent(String _myMessage) {
		this.myMessage = _myMessage;
		System.out.println("Parent constructor have a String argument call. ");
	}
	
	public String getMessage() {
		//return "Parent Message";
		return myMessage;
	}
}
