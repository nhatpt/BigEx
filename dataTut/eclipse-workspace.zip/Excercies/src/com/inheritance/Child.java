package com.inheritance;

public class Child extends Parent {
	private String myMessage;
	Child() {
		System.out.println("Child default constructor");
	}
	Child(String _myMessage){
		super("Parent Message");
		this.myMessage = _myMessage;
		System.out.println("Child constructor have a String argument call. ");
	}
	@Override
	//Covariant return type
	public String getMessage() {
		//return "Child Message";
		return super.myMessage + " and " + this.myMessage;
	}
	
	public static void main(String[] args) {
		Child ch  = new Child("Child Message.");
		//Child ch  = new Child();
		System.out.println(ch.getMessage());
	}
}
