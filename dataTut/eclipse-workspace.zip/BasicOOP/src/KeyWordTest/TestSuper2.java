package KeyWordTest;

class Animal {
	void eat() {
		System.out.println("Animal eating...");
	}
}

class Dog extends Animal {
	void eat() {
		System.out.println("Dog eating bread...");
	}

	void run() {
		System.out.println("Dog running...");
	}

	void work() {
		super.eat();
		run();
	}
}

class TestSuper2 {
	public static void main(String args[]) {
		Dog d = new Dog();
		d.work();
	}
}