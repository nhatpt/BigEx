package KeyWordTest;

class A{
	String names = "I am super.";
	
}

class B extends A{
	String names = "I am child";
	void display() {
		System.out.println(super.names);
		System.out.println(names);	
	}
}

public class TestSuper {
	public static void main(String[] args) {
		new B().display();
	}
}

