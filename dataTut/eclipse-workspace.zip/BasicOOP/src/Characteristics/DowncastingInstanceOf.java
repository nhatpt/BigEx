package Characteristics;

class A3 {
}

class B3 extends A3 {
	void display(A3 a) {
		if(a instanceof B3) {
			System.out.println("Success");
		}
		else
			System.out.println("Nooooooo");
	}
}

public class DowncastingInstanceOf {
	public static void main(String[] args) {
		A3 a3 = new B3();
		B3 b3 = new B3();
		b3.display(a3);
	}
}
