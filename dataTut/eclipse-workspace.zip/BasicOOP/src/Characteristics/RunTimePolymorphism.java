package Characteristics;

class A {
	void run () {
		System.out.println("A is running");
	}
}

class B extends A{
	@Override
	void run() {
		System.out.println("B is running");
	}
}	

public class RunTimePolymorphism {
	public static void main(String[] args) {
		A a = new B();
		a.run();
	}
}
