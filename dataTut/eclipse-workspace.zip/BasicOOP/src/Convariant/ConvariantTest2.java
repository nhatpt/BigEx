package Convariant;

class A1 {
	
	 int Mul (int a, int b) {
		return a*b;
	}
}

class B1 extends A1 {
	 double Mul (double a, double b) {
		return a*b;
	}
}


public class ConvariantTest2 {
	public static void main(String[] args) {
		System.out.println(new B1().Mul(3.2, 7.0));
		System.out.println(new A1().Mul(3, 7));
		
	}
}
