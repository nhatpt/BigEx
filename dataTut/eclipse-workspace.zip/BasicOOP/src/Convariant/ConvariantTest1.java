package Convariant;

class A{
	A get() {
		return this;
	}
	void message() {
		System.out.println("Hello this is A");
	}
}

class B extends A{
	B get() {
		return this;
	}
	void message() {
		System.out.println("Hello this is B");
	}
}

public class ConvariantTest1 {
	public static void main(String[] args) {
		new B().get().message();
	}
}

