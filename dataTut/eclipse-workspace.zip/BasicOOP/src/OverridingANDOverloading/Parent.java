package OverridingANDOverloading;

public class Parent {
	public Parent() {
	}
	void display() {
		System.out.println("Parent say hi");
	}
}
