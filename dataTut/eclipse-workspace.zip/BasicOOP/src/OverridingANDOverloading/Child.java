package OverridingANDOverloading;

public class Child extends Parent {
	public Child() {
	}
	
	@Override
	void display() {
		System.out.println("Child say Hello");
	}
}
