package OverridingANDOverloading;

public class Main {
	public static void main(String[] args) {
		Parent pr = new Parent();
		Parent ch = new Child();
		
		pr.display();
		ch.display();
	}
}
