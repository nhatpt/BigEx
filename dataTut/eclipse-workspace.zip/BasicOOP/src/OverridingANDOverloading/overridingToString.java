package OverridingANDOverloading;

class Human{
	int age;
	String name;
	public Human(int _age, String _name) {
		this.age = _age;
		this.name = _name;
	}
	@Override
	public String toString() {
		return "Age: " + age + "\nName: " + name;
	}
	
}

public class overridingToString {
	public static void main(String[] args) {
		Human human = new Human(22, "Nhat");
		System.out.println(human);
	}
}
