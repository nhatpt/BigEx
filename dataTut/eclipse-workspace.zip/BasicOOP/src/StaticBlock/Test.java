package StaticBlock;

public class Test {
	static int i;
	static {
		i = 10;
		System.out.println("This is a static block");
	}
	
	public Test() {
		
	}
	
	void display() {
		System.out.println("Test Class called Static Block");
	}
}
