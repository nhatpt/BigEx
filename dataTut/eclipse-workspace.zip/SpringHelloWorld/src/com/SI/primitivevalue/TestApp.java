package com.SI.primitivevalue;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {
	private static ApplicationContext context;
	public static void main(String[] args) {
		context = new ClassPathXmlApplicationContext("SIprimitive.xml");
		Student st = (Student) context.getBean("st");
		System.out.println(st.getId() + " " + st.getName() + " "+ st.getClassName());
	}
}
