package com.factorymethod;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {
	private static ApplicationContext context;

	public static void main(String[] args) {
		context = new ClassPathXmlApplicationContext("factoryMethod.xml");
		StaticMethodClass smc = (StaticMethodClass) context.getBean("a");
		smc.msg();

		context = new ClassPathXmlApplicationContext("factoryMethodInOtherClass.xml");
		StaticMethodOtherClassInterface si = (StaticMethodOtherClassInterface) context.getBean("sttother2");
		si.print();
	}
}
