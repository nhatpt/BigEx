package com.factorymethod;

public interface StaticMethodOtherClassInterface {
	void print();
}
