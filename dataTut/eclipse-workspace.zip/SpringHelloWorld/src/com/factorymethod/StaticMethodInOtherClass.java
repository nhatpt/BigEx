package com.factorymethod;

public class StaticMethodInOtherClass  implements StaticMethodOtherClassInterface{
	@Override
	public void print() {
		System.out.println("I am A");
	}
}
