package com.factorymethod;

public class StaticMethodClass {
	private static StaticMethodClass obj;

	private StaticMethodClass() {
		System.out.println("private constructor");
	}

	public static StaticMethodClass getStaticMethodClass() {
		System.out.println("factory method");
		if (obj == null) {
			obj = new StaticMethodClass();
		}
		return obj;
	}

	public void msg() {
		System.out.println("hello");
	}
}


