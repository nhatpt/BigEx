package com.factorymethod;

public class FactoryClass {
	public static StaticMethodOtherClassInterface getClassOther() {
		return new StaticMethodInOtherClass();
	}
}
