package com.dependency.injection;

public class TextEditor {
	private SpellChecker spellChecker;

	public TextEditor() {
		System.out.println("TextEditor constructor.");
	}
	
	public TextEditor(SpellChecker spellChecker) {
		System.out.println("TextEditor constructor has arg.");
		this.spellChecker = spellChecker;
	}

	public void spellCheck() {
		System.out.println("Checking TextEditor...");
		spellChecker.checkSpelling();
	}

	public SpellChecker getSpellChecker() {
		return spellChecker;
	}

	public void setSpellChecker(SpellChecker spellChecker) {
		this.spellChecker = spellChecker;
	}
}


