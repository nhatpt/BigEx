package com.dependency.injection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppMain {
	private static ApplicationContext context;

	public static void main(String[] args) {
//		context = new ClassPathXmlApplicationContext("beansDI.xml");
//		TextEditor te = (TextEditor) context.getBean("textEditor");
//		te.spellCheck();
		
		context = new ClassPathXmlApplicationContext("Autowire.xml");
		TextEditor te2 = (TextEditor) context.getBean("TextEditor");
		te2.spellCheck();
	}
}
