package com.dependency.injection;

public class SpellChecker {
	
	public SpellChecker() {
		System.out.println("SpellChecker constructor.");
	}

	public void checkSpelling() {
		System.out.println("CheckSpelling...");
	}
}

