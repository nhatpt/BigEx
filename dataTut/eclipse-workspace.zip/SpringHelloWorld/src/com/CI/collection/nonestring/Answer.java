package com.CI.collection.nonestring;

public class Answer {
	private int id;
	private String name;

	public Answer() {
	}

	public Answer(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public String toString() {
		return id + " " + name;
	}
}
