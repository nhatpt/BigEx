package com.CI.collection.nonestring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {
	private static ApplicationContext context;
	public static void main(String[] args) {
		context = new ClassPathXmlApplicationContext("beansCINoneString.xml");
		Question q = (Question)context.getBean("question");
		q.displayInfo();
	}
}
