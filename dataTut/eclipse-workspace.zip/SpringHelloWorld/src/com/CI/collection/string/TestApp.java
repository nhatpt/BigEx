package com.CI.collection.string;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {
	private static ApplicationContext context;

	public static void main(String[] args) {
		 context = new ClassPathXmlApplicationContext("beansCIString.xml");
	     Question obj = (Question) context.getBean("question");
	     obj.displayInfo();
	}
}
