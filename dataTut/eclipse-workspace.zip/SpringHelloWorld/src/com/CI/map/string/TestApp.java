package com.CI.map.string;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {
	private static ApplicationContext context;
	public static void main(String[] args) {
		context = new ClassPathXmlApplicationContext("CIMap.xml");
		Question qm = (Question) context.getBean("question");
		qm.displayInfo();
	}
}
