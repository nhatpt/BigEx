package com.CI.map.nonestring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestApp {
	//Init a IoC containner
	private static ApplicationContext context;

	public static void main(String[] args) {
		context = new ClassPathXmlApplicationContext("beansCINoneMap.xml");
		QuestionCINoneString qu = (QuestionCINoneString) context.getBean("question");
		qu.displayInfo();
	}
}
