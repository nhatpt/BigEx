package helloWorld;

public class Operator {
	public static void main(String[] args) {
		//Unary Operator:
		int x = 1; int s1 = 2; int s2 = 2;
		s1 = s1 + (x--); 
		System.out.println(s1);
		s2 = s2 + (--x);
		System.out.println(s2);
		System.out.println(~5);
		
		
		//Shift
		System.out.println(100>>3);
		System.out.println(100<<3);
		
		//Ternary:
		int a = 10;
		int b = 15;
		//If - else
		if(a > b) {
			System.out.println(a);
		}
		else
			System.out.println(b);
		
		//Ternary - One line:
		System.out.println(a>b?a:b);
	}
}
