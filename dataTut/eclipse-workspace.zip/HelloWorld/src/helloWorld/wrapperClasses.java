package helloWorld;

public class wrapperClasses {
	public static void main(String[] args) {
		
		//Autuboxing
		boolean boo = false;
		Boolean Boo = new Boolean(boo);
		
		short sh = 10;
		Short Sh = new Short(sh);
		
		int i = 100;
		Integer In = new Integer(i);
		
		double dou = 200.567;
		Double Dou = new Double(dou);
		
		char ch = 'S';
		Character Ch = new Character(ch);
		
		System.out.println("Wrapper Class of Primitive data type:");
		System.out.println("\tWrapper Class of Boolean: " + Boo);
		System.out.println("\tWrapper Class of Short: " + Sh);
		System.out.println("\tWrapper Class of Integer: " + In);
		System.out.println("\tWrapper Class of Double: " + Dou);
		System.out.println("\tWrapper Class of Character: " + Ch);
		
		
		//UnBoxing 
		Boolean B = new Boolean(true);
		boolean b = B;
		System.out.println("Unboxing Boolean:" + b);
		
		
	}
}
