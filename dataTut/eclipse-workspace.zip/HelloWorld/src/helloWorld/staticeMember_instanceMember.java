package helloWorld;

public class staticeMember_instanceMember {
	private static int x;

	//static member
	public static void staticSum() {
		int a = 3; //instance var
		int b = 4;//instance var
		x = 12; //static var
		System.out.println(a + b + x);
	}

	//instance member
	public void instanceSum() {
		int a = 3;//instance var
		int b = 10;//instance var
		System.out.println(a + b + x);
	}

	public static void main(String[] args) {
		//Call static member
		staticSum();
		
		//Call instance member
		staticeMember_instanceMember sm = new staticeMember_instanceMember();
		sm.instanceSum();
	}
	
}
