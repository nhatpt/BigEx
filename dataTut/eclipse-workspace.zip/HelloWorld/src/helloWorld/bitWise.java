package helloWorld;

public class bitWise {
	public static void main(String[] args) {
		int a = 10;
		int b = 5;
		int c = 11;
		if(a>b || a++<c) {
			System.out.println(a);
		}
		
		if(a>b | a++<c) {
			System.out.println(a);
		}
		
	}
}
