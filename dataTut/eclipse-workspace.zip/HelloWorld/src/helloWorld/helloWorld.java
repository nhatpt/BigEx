package helloWorld;

public class helloWorld {
	String nameLang;
	
	public helloWorld(String _nameLang) {
		this.nameLang = _nameLang;
	}
	
	
	public void getName() {
		System.out.println(nameLang);
	}
	
	/*
	 This is a comment template This is a comment template 
	 This is a comment template
	 */
	
	/*
	 * This is a comment template This is a comment template This is a comment
	 * template
	 */
	
	//This is the main of class:
	public static void main(String[] args) {
		helloWorld hw1 = new helloWorld("Java");
		helloWorld hw2 = hw1;
		hw1.nameLang = "JavaScript";
		hw1.getName();
		hw2.getName();
	}
}
