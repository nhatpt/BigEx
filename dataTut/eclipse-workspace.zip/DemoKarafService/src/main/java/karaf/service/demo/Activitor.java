package karaf.service.demo;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

import karaf.service.demo.noneimpl.MathUtils;
import karaf.service.demo.service.MathService;
import karaf.service.demo.service.impl.MathServiceImpl;

public class Activitor implements BundleActivator {

	private static BundleContext context;

	static BundleContext getContext() {
		return context;
	}

	public void start(BundleContext bundleContext) throws Exception {
		Activitor.context = bundleContext;
		System.out.println("Registry Service MathService...");
		this.registryMathService();
		System.out.println("OSGi MathService Started");
		System.out.println("17 - 2 = " + MathUtils.sub(17, 2));

		ServiceReference<?> serviceReference = context.getServiceReference(MathService.class);
		MathService service = (MathService) context.getService(serviceReference);

		System.out.println("5 + 4 = " + service.sum(5, 4));
		
		System.out.println("MathConsumer Started");
	}

	private void registryMathService() {
		MathService service = new MathServiceImpl();
		context.registerService(MathService.class, service, null);
	}

	public void stop(BundleContext bundleContext) throws Exception {
		Activitor.context = null;
		System.out.println("OSGi MathService Stopped!");
	}
}
