package karaf.service.demo.service;

public interface MathService {
	 public int sum(int a, int b);
}
