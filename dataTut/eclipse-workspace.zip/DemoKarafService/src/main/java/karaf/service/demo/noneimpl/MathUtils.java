package karaf.service.demo.noneimpl;

public class MathUtils {
	public static int sub(int a, int b) {
		return a-b;
	}
}
