package karaf.service.demo.service.impl;

import karaf.service.demo.service.MathService;

public class MathServiceImpl implements MathService {

	@Override
	public int sum(int a, int b) {
		return a+b;
	}

}
