package app;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entities.Student;

public class Main {
	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		Session curSession1 = sessionFactory.openSession();
		Session curSession2 = sessionFactory.openSession();
		curSession1.beginTransaction();
		curSession2.beginTransaction();


		Student st1 = curSession1.load(Student.class, 14);
		System.out.println(st1.getFirstName());

		Student st2 = curSession2.load(Student.class, 14);
		System.out.println(st2.getFirstName());

		curSession1.close();
		curSession2.close();
		sessionFactory.close();

	}
}
