package entities;

public class Student {
	private int id;
	private String f_name;
	private String l_name;
	private String className;
	private String rollNo;
	private int Age;

	public Student() {
		
	}
	
	public Student( String f_name, String l_name, String className, String rollNo, int age) {
		super();
		this.f_name = f_name;
		this.l_name = l_name;
		this.className = className;
		this.rollNo = rollNo;
		Age = age;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getF_name() {
		return f_name;
	}

	public void setF_name(String f_name) {
		this.f_name = f_name;
	}

	public String getL_name() {
		return l_name;
	}

	public void setL_name(String l_name) {
		this.l_name = l_name;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}
}
