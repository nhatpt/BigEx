package dao;

import java.util.List;

import entities.Student;

public interface StudentDAOInterface {
	Integer add(Student d);
	void delete(Student d);
	void update(Student d);
	List<Student> showAll();
}
