package app;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import dao.StudentDAOInterface;
import entities.Student;

public class TestApp {
	private static ApplicationContext contex;
	public static void main(String[] args) {
		contex = new ClassPathXmlApplicationContext("applicationContext.xml");
		StudentDAOInterface st =(StudentDAOInterface) contex.getBean("student");
		
		Student addst = new Student("NewMan", "Kane", "Rc/12.e4", "12/RoolN", 23);
		st.add(addst);
		
		List<Student> students = st.showAll();
		for (Student eSt : students) {
			System.out.println("Id No: " + eSt.getId());
			System.out.println("First Name: " + eSt.getF_name());
			System.out.println("Last Name: " + eSt.getL_name());
			System.out.println("Class: " + eSt.getClassName());
			System.out.println("RollNo: " + eSt.getRollNo());
			System.out.println("Age: " + eSt.getAge());
		}
	}
}

