package org.apachekaraf.simpleproject.able;

public interface HelloWorldService {
	String hello(String name);
}
