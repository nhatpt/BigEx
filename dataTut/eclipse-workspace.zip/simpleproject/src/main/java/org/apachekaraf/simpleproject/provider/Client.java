package org.apachekaraf.simpleproject.provider;

import org.apachekaraf.simpleproject.able.HelloWorldService;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceEvent;
import org.osgi.framework.ServiceListener;
import org.osgi.framework.ServiceReference;

public class Client implements BundleActivator, ServiceListener {
	private BundleContext ctx;
	private ServiceReference<HelloWorldService> serviceReference;

	
	@Override
	public void serviceChanged(ServiceEvent event) {
		int type = event.getType();
		switch (type) {
		case (ServiceEvent.REGISTERED):
			System.out.println("Notification of service registered.");
			serviceReference =  (ServiceReference<HelloWorldService>) event.getServiceReference();
			HelloWorldService service = (HelloWorldService) (ctx.getService(serviceReference));
			System.out.println(service.hello("Taki"));
			break;
		case (ServiceEvent.UNREGISTERING):
			System.out.println("Notification of service unregistered.");
			ctx.ungetService(event.getServiceReference());
			break;
		default:
			break;
		}
	}

	@Override
	public void start(BundleContext context) throws Exception {
		this.ctx = context;
		try {
			ctx.addServiceListener(this, "(objectclass=" + HelloWorldService.class.getName() + ")");
		} catch (InvalidSyntaxException ise) {
			ise.printStackTrace();
		}
	}

	@Override
	public void stop(BundleContext context) throws Exception {
		if (serviceReference != null) {
			System.out.println("Stopping service");
			ctx.ungetService(serviceReference);
		}
	}

}
