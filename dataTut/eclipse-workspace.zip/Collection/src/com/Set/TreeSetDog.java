package com.Set;

public class TreeSetDog implements Comparable<TreeSetDog> {
	private int size;

	public TreeSetDog(int s) {
		size = s;
	}

	public String toString() {
		return size + "";
	}

	@Override
	public int compareTo(TreeSetDog o) {
		// TODO Auto-generated method stub
		return this.size -  o.size;
	}
}
