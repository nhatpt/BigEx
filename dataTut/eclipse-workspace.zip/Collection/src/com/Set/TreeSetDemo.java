package com.Set;

import java.util.*;

class TreeSetDemo {
	public static void main(String[] args) {
		TreeSet<TreeSetDog> dset = new TreeSet<TreeSetDog>();
		dset.add(new TreeSetDog(2));
		dset.add(new TreeSetDog(1));
		dset.add(new TreeSetDog(3));

		Iterator<TreeSetDog> iterator = dset.iterator();
		while (iterator.hasNext()) {
			System.out.print(iterator.next() + " ");
		}
	}
}
