package com.Set;
import java.util.*;
public class HashSetDemo {
	public static void main(String[] args) {
		HashSet<String> hashset = new HashSet<String>();
		hashset.add("One");
		hashset.add("Two");
		hashset.add("Three");
		hashset.add("Four");
		hashset.add("Five");
		hashset.add("Six");
		
		Iterator<String> i = hashset.iterator();// Tranfers HashSet to Iterator
		while (i.hasNext()) {
			System.out.println(i.next());
		}
	}
}
