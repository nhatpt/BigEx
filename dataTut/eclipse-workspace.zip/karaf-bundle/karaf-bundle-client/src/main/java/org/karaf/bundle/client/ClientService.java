package org.karaf.bundle.client;

import java.util.List;

import org.karaf.bundle.common.Booking;

public interface ClientService {
	List<Booking> bookings();
	void addBooking(Booking booking);
}
