package org.karaf.bundle.provider;

import org.karaf.bundle.common.BookingService;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Activator implements BundleActivator {
	private ServiceRegistration<BookingService> serviceRegistration;

	@Override
	public void start(BundleContext context) throws Exception {
		// create a booking service impl instance
		BookingServiceImpl bookingService = new BookingServiceImpl();
		// registering the booking service in the service registry
		serviceRegistration = context.registerService(BookingService.class, bookingService, null);
	}

	@Override
	public void stop(BundleContext context) throws Exception {
		if (serviceRegistration != null) {
			// remove the service from the service registry
			serviceRegistration.unregister();
		}
	}

}
