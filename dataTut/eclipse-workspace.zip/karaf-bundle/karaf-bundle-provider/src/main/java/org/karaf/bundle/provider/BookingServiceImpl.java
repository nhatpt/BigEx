package org.karaf.bundle.provider;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.karaf.bundle.common.Booking;
import org.karaf.bundle.common.BookingService;

public class BookingServiceImpl implements BookingService {

	private Map<Long, Booking> bookings = new HashMap<>();

    @Override
    public List<Booking> list() {
        return new LinkedList<>(bookings.values());
    }

    @Override
    public Booking get(Long id) {
        return bookings.get(id);
    }

    @Override
    public void add(Booking booking) {
        bookings.put(booking.getId(), booking);
    }

}
