package ForEachFeture;

import java.util.HashMap;

public class ForEachMap {
	public static void main(String[] args) {
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		hm.put(1, "A");
		hm.put(2, "A");
		hm.put(3, "C");
		hm.put(4, "B");
		hm.put(5, "1");		
		hm.forEach((k,v)->System.out.println(k + " - " + v));
	}
}
