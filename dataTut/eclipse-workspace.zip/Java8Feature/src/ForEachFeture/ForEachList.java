package ForEachFeture;

import java.util.Arrays;
import java.util.List;

public class ForEachList {
	public static void main(String[] args) {
		List<String> fruits = Arrays.asList("Apple", "Banana", "Samsung", "Xiaomi", "Huawwei");
		// lambda expression in forEach Method
		fruits.forEach(str -> System.out.println(str));
		System.out.println("===========");
		// Method reference in forEach Method:
		fruits.forEach(System.out::println);
	}
}