package StringJoiner;

import java.util.StringJoiner;

public class StringJoinerTest {

	public static void main(String[] args) {
		/*
		 * Passing comma(,) as delimiter and opening bracket "(" as prefix and closing
		 * bracket ")" as suffix
		 */
		StringJoiner mystring = new StringJoiner(",", "(", ")");

		// Joining multiple strings by using add() method
		mystring.add("Negan");
		mystring.add("Rick");
		mystring.add("Maggie");
		mystring.add("Daryl");

		// Displaying the output String
		System.out.println(mystring);

		StringJoiner mystring2 = new StringJoiner("-", "(", ")");
		mystring2.add("Negan2");
		mystring2.add("Rick2");
		mystring2.add("Maggie2");
		mystring2.add("Daryl2");
		// Displaying the output String
		System.out.println(mystring2);
		
		//Display merge String
		StringJoiner myString2 = mystring.merge(mystring2);
		System.out.println(myString2);
	}
}
