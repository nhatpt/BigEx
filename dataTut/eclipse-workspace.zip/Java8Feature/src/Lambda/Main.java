package Lambda;

import java.util.*;

class Main {
	public static void main(String[] args) {
		SayHi msg = () -> {
			return "Hello My Friend";
		};
		
		System.out.println(msg.HiWorld());
		
		LambdaWithParameter lbs = (a, b) -> {
			if(a> b) {
				return  a + b;
			}
			else
				return a+2*b;
			
		};
		System.out.println(lbs.Sum(1, 2));
		
		LinkedList<String> ls = new LinkedList<String>();
		ls.add("B");
		ls.add("A");
		ls.add("F");
		ls.add("M");
		ls.add("A");
		ls.add("Q");
		ls.add("C");
		ls.add("D");
		
		ls.forEach(names->System.out.println(names));
		System.out.println("==============================");
		ls.stream().forEach(names->System.out.println(names));
	}
}
