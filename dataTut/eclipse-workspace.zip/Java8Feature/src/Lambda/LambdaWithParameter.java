package Lambda;

public interface LambdaWithParameter {
	public int Sum(int a, int b);
}
