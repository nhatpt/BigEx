package Lambda;

interface myInterface{
	int Sum (int a, int b);
}
public class OwnInterfaceLambda {
	public static void main(String[] args) {
		myInterface mi = (a, b) -> a + b;
		int sum = mi.Sum(12, 33);
		System.out.println(sum);
	}
}
