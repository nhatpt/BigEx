package Lambda;

public interface SayHi {
	public String HiWorld();
	public default String HelloW() {
		return null;
	}
}