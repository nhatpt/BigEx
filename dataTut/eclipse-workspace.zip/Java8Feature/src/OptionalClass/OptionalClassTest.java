package OptionalClass;

import java.util.Optional;

public class OptionalClassTest {
	public static void main(String[] args) {
		String[] str = new String[10];
		str[9] = "Test Optional Class.";
		Optional<String> checkString = Optional.ofNullable(str[9]);
		if (checkString.isPresent()) {
			System.out.println(str[9].substring(2, 8));
		} else {

			System.out.println("Cannot get the substring from an empty string");
		}

	}
}

