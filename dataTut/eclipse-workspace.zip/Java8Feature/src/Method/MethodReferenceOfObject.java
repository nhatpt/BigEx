package Method;

interface MethodReference {
	void display();
}

public class MethodReferenceOfObject {
	void myMethodReference() {
		System.out.println("Method Reference");
	}
	public static void main(String[] args) {
		MethodReferenceOfObject mro = new MethodReferenceOfObject();
		//Using method reference
		MethodReference mr = mro::myMethodReference;
		mr.display();
		
		//Using lambda:
		MethodReference lmr = ()-> mro.myMethodReference();
		lmr.display();
	}
	
}


