package Method;

import java.util.function.IntSupplier;

interface MethodRef{
	MethodHaveConstructor constructor(int a, int b);
}

class MethodHaveConstructor {
	static int a;
	static int b;
	

	MethodHaveConstructor(int _a, int _b) {
		MethodHaveConstructor.a = _a;
		MethodHaveConstructor.b = _b;
	}
	
	public static int Sum() {
		return a + b;
	}
}

class MethodRefAConstructor {
	public static void main(String[] args) {
		MethodRef ref = MethodHaveConstructor::new;
		ref.constructor(8,3);
		
		IntSupplier sum = MethodHaveConstructor::Sum;
		System.out.println(sum.getAsInt());
	}
}
