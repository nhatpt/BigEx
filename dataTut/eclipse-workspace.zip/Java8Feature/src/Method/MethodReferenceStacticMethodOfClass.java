package Method;

import java.util.function.*;

class Multiplication {
	public static int multi(int a, int b) {
		return a*b;
	}
}

public class MethodReferenceStacticMethodOfClass {
	public static void main(String[] args) {
		//Using method reference with BiFunction - predefined functional interface
		BiFunction<Integer, Integer, Integer> pre = Multiplication::multi;
		int result = pre.apply(10, 10);
		System.out.println(result);
		
		//Using lambda with IntBinaryOperator - predefined functional interface
		IntBinaryOperator mul = (a, b)-> Multiplication.multi(a, b);
		int res = mul.applyAsInt(100, 10);
		System.out.println(res);
	}
}

