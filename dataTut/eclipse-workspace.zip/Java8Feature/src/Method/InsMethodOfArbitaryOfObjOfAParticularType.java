package Method;
import java.util.*;

public class InsMethodOfArbitaryOfObjOfAParticularType {
	public static void main(String[] args) {
		List<String> names = Arrays.asList("Hoàng", "Tú", "Chi", "Mai", "Hương", "Giang", "Hùng");
		System.out.println(names);
		
		Collections.sort(names, String::compareTo);
		System.out.println(names);
	}
}
