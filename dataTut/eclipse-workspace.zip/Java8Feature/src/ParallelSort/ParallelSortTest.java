package ParallelSort;

import java.util.Arrays;

public class ParallelSortTest {
	public static void main(String[] args) {
		int [] numbers =  {1, 3, 45, 7, 8, 10, 9, 0, 2};
		Arrays.parallelSort(numbers, 3, 6);
		Arrays.stream(numbers).forEach(n -> System.out.print(n + " "));
	}
}
