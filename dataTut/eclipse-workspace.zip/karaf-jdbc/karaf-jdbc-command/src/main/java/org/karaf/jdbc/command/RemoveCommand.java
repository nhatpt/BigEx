package org.karaf.jdbc.command;

import java.util.List;

import org.apache.karaf.shell.api.action.Action;
import org.apache.karaf.shell.api.action.Argument;
import org.apache.karaf.shell.api.action.Command;
import org.apache.karaf.shell.api.action.Completion;
import org.apache.karaf.shell.api.action.lifecycle.Reference;
import org.apache.karaf.shell.api.action.lifecycle.Service;
import org.karaf.jdbc.api.BookingService;
import org.karaf.jdbc.completers.BookingIdCompleter;

@Service
@Command(scope = "booking", name = "remove", description = "Remove an existing bookings")
public class RemoveCommand implements Action {
	@Reference
	private BookingService bookingService;

	@Argument(index = 0, name = "ids", description = "List of bookings to remove", required = true, multiValued = true)
	@Completion(BookingIdCompleter.class)
	List<Long> ids;

	@Override
	public Object execute() throws Exception {
		for (Long id : ids) {
			bookingService.remove(id);
		}
		return null;
	}
}
