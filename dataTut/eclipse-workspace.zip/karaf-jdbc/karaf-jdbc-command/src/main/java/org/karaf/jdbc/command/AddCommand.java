package org.karaf.jdbc.command;

import java.util.Random;

import org.apache.karaf.shell.api.action.Action;
import org.apache.karaf.shell.api.action.Argument;
import org.apache.karaf.shell.api.action.Option;
import org.apache.karaf.shell.api.action.lifecycle.Reference;
import org.karaf.jdbc.api.Booking;
import org.karaf.jdbc.api.BookingService;

public class AddCommand implements Action {
	@Reference
	private BookingService bookingService;

	@Option(name = "-i", aliases = "--id", description = "Booking ID", required = false, multiValued = false)
	Long id = 0L;

	@Argument(index = 0, name = "customer", description = "Booking customer", required = true, multiValued = false)
	String customer;

	@Argument(index = 1, name = "flight", description = "Booking flight", required = true, multiValued = false)
	String flight;

	@Override
	public Object execute() throws Exception {
		Booking booking = new Booking();
		if (id == 0) {
			Random random = new Random();
			id = new Long(random.nextInt(9000000) + 1000000);
		}
		booking.setId(id);
		booking.setCustomer(customer);
		booking.setFlight(flight);
		bookingService.add(booking);
		return null;
	}
}
