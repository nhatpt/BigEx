package org.karaf.jdbc.command;

import org.karaf.jdbc.completers.BookingIdCompleter;
import org.apache.karaf.shell.api.action.Action;
import org.apache.karaf.shell.api.action.Argument;
import org.apache.karaf.shell.api.action.Command;
import org.apache.karaf.shell.api.action.Completion;
import org.apache.karaf.shell.api.action.lifecycle.Reference;
import org.apache.karaf.shell.api.action.lifecycle.Service;
import org.apache.karaf.shell.support.table.ShellTable;
import org.karaf.jdbc.api.Booking;
import org.karaf.jdbc.api.BookingService;

@Service
@Command(scope = "booking", name = "get", description = "Get the booking by id")
public class GetCommand implements Action {

	@Reference
	private BookingService bookingService;

	@Argument(index = 0, name = "id", description = "Id of booking to retreive", required = true, multiValued = false)
	@Completion(BookingIdCompleter.class)
	Long id;

	@Override
	public Object execute() throws Exception {
		ShellTable table = new ShellTable();
		table.column("ID");
		table.column("Flight");
		table.column("Customer");
		Booking booking = bookingService.get(id);
		table.addRow().addContent(booking.getId(), booking.getFlight(), booking.getCustomer());
		table.print(System.out);
		return null;
	}
}
