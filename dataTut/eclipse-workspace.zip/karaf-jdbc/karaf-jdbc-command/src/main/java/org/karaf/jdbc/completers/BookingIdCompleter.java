package org.karaf.jdbc.completers;

import java.util.List;

import org.apache.karaf.shell.api.action.lifecycle.Reference;
import org.apache.karaf.shell.api.action.lifecycle.Service;
import org.apache.karaf.shell.api.console.CommandLine;
import org.apache.karaf.shell.api.console.Completer;
import org.apache.karaf.shell.api.console.Session;
import org.apache.karaf.shell.support.completers.StringsCompleter;
import org.karaf.jdbc.api.Booking;
import org.karaf.jdbc.api.BookingService;

@Service
public class BookingIdCompleter implements Completer {
	@Reference
	private BookingService bookingService;

	@Override
	public int complete(Session session, CommandLine commandLine, List<String> candidates) {
		StringsCompleter delegate = new StringsCompleter();
		for (Booking booking : bookingService.list()) {
			delegate.getStrings().add(String.valueOf(booking.getId()));
		}
		return delegate.complete(session, commandLine, candidates);
	}
}
