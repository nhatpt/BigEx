package org.karaf.jdbc.command;

import org.apache.karaf.shell.api.action.Action;
import org.apache.karaf.shell.api.action.Command;
import org.apache.karaf.shell.api.action.lifecycle.Reference;
import org.apache.karaf.shell.api.action.lifecycle.Service;
import org.apache.karaf.shell.support.table.ShellTable;
import org.karaf.jdbc.api.Booking;
import org.karaf.jdbc.api.BookingService;

@Service
@Command(scope = "booking", name = "list", description = "List the current bookings")
public class ListCommand implements Action {
	@Reference
	private BookingService bookingService;

	@Override
	public Object execute() throws Exception {
		ShellTable table = new ShellTable();
		table.column("ID");
		table.column("Flight");
		table.column("Customer");
		for (Booking booking : bookingService.list()) {
			table.addRow().addContent(booking.getId(), booking.getFlight(), booking.getCustomer());
		}
		table.print(System.out);
		return null;
	}

}
