package factoryPattern;

public class Client {
	public static void main(String[] args) {
		Computer pc = ComputerFactory.getComputer("pc", "12GB", "3.0 GHz", "1TB");
		Computer server = ComputerFactory.getComputer("server", "100 GB", "5.5 GHz", "10TB");
		System.out.println(pc);
		System.out.println(server);
	}
}
