package factoryPattern;

public abstract class Computer {
	abstract String RAM();
	abstract String CPU();
	abstract String STORGE();
	
	@Override
	  public String toString(){
	    return "RAM= "+this.RAM()+", CPU= "+this.CPU()+", STORGE="+this.STORGE() ;
	  }
}
