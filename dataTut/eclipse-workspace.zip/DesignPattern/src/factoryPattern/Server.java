package factoryPattern;

public class Server extends Computer{
	
	private String ram;
	private String cpu;
	private String storge;
	
	public Server(String _ram, String _cpu, String _storge) {
		// TODO Auto-generated constructor stub
		ram = _ram;
		cpu = _cpu;
		storge = _storge;
	}
	
	
	@Override
	String RAM() {
		// TODO Auto-generated method stub
		return this.ram;
	}

	@Override
	String CPU() {
		// TODO Auto-generated method stub
		return this.cpu;
	}

	@Override
	String STORGE() {
		// TODO Auto-generated method stub
		return this.storge;
	}
}
