package factoryPattern;

public class ComputerFactory {
	public static Computer getComputer (String type, String ram,  String cpu, String storge) {
		if("PC".equalsIgnoreCase(type))
			return new PC(ram, cpu, storge);
		else if("Server".equalsIgnoreCase(type))
			return new Server(ram, cpu, storge);
		return null;
	}
}
