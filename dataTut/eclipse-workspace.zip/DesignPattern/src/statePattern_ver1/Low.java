package statePattern_ver1;

public class Low implements State {

	@Override
	public void pull(CeilingFanPullChain cl) {
		// TODO Auto-generated method stub
		cl.setState(new Medium());
		System.out.println("\tMedium Speed");
	}

}
