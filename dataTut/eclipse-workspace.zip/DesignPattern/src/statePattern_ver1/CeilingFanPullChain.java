package statePattern_ver1;

public class CeilingFanPullChain {
	private State state;
	
	public CeilingFanPullChain() {
		state = new Off();
	}
	
	public void setState(State st) {
		this.state = st;
	}
	
	public void pull() {
		state.pull(this);
	}
}

