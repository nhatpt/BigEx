package statePattern_ver1;

public interface State {
	void pull(CeilingFanPullChain cl);
}
