package statePattern_ver1;

public class High implements State {

	@Override
	public void pull(CeilingFanPullChain cl) {
		// TODO Auto-generated method stub
		cl.setState(new Off());
		System.out.println("\t Off Speed");
	}

}
