package statePattern_ver1;

public class Medium implements State {

	@Override
	public void pull(CeilingFanPullChain cl) {
		// TODO Auto-generated method stub
		cl.setState(new High());
		System.out.println("\tHigh Speed");
	}
	
}
