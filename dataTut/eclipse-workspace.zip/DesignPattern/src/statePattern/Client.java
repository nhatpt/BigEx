package statePattern;

public class Client {
	 public static void main(String[] args) {
	      Context context = new Context();

	      startState startState = new startState();
	      startState.doAction(context);
	      
	      stopState stopState = new stopState();
	      stopState.doAction(context);

	   }
}
