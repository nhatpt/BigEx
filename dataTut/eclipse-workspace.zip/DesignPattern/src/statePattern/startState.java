package statePattern;

//State action of State
public class startState implements State{

	@Override
	public void doAction(Context context) {
		// TODO Auto-generated method stub
		 System.out.println("Player is in start state");
	     context.setState(this);	
	}
}
