package statePattern;

public interface State {
	public void doAction(Context context);//An action
}
