package statePattern;

public class Context {
	private State state;

	public Context() {
		state = new stopState();
	}

	public void setState(State state) {
		this.state = state;
	}

	public State getState() {
		return state;
	}

	public void doAction() {
		state.doAction(this);
	}
}
