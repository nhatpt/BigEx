package ObserverPattern;

public class ConcreateObserver_CurrentConditionsDisplay implements Observer, DisplayElement{

	private float temperature;
    private float humidity;
    
    public ConcreateObserver_CurrentConditionsDisplay( ) {
	
	}
    
	@Override
	public void display() {
		// TODO Auto-generated method stub
        System.out.println("Current conditions: "
		+ temperature + " F degrees and " + humidity + "% humidity");
	}

	@Override
	public void update(float temp, float humidity, float pressure) {
		// TODO Auto-generated method stub
		 this.temperature = temp;
	     this.humidity = humidity;
	     display();
	}

}
