package ObserverPattern;

public class Client {
	public static void main(String[] args) {
		ConcreateSubject_WeatherData wd = new ConcreateSubject_WeatherData();
		ConcreateObserver_CurrentConditionsDisplay cdd = new ConcreateObserver_CurrentConditionsDisplay();
		ConcreateObserver_ForecastDisplay fd = new ConcreateObserver_ForecastDisplay();
		wd.registerObserver(cdd);
		wd.registerObserver(fd);
		
		wd.setMeasurements(10, 20, 30);
		wd.setMeasurements(30, 220, 130);
		
	}
}
