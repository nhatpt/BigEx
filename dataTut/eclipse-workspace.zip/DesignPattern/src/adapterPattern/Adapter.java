package adapterPattern;

public class Adapter implements PhoneTarget{
	checkNumber cn = new checkNumber();

	@Override
	public boolean checkPhoneNumber(String input) {
	    if (!cn.checkNumberPhone(input)) {
	        return false;
	      }
	      return true;
	}
	
}
