package adapterPattern;

public interface PhoneTarget {
	boolean checkPhoneNumber(String input);
}
