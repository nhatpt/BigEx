package adapterPattern;

class checkNumber {
	boolean checkNumberPhone (String input) {
	    String regex = "(09)+([0-9]{8})";
	    return input.matches(regex);
	 }
}
