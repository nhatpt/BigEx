package abstractFacotyPattern;

public interface ComputerAbstractFactory {
	  public Computer createComputer();
}
