package strategyPattern;

import java.util.Comparator;
import java.util.List;

public class SelectionSort implements SortStrategy {

	@Override
	public List<String> sort(List<String> items) {
		// TODO Auto-generated method stub
		items.sort(Comparator.naturalOrder());
		return items;
	}

	
}
