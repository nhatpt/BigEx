package strategyPattern;

import java.util.List;

public interface SortStrategy {
	List<String> sort(List<String> items);
}
