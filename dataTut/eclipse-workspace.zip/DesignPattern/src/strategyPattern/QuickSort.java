package strategyPattern;

import java.util.List;

public class QuickSort implements SortStrategy{

	@Override
	public List<String> sort(List<String> items) {
		// TODO Auto-generated method stub
		items.sort(String.CASE_INSENSITIVE_ORDER);
		return items;
	}

}
