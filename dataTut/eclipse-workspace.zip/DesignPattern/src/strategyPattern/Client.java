package strategyPattern;

public class Client {
	public static void main(String[] args) {
		 
        SortContext sortedList = new SortContext();
        sortedList.add("Java Design Pattern");
        sortedList.add("Java Core");
        sortedList.add("Java Framework");
        sortedList.add("Java Library");
        System.out.println("=========================List==============================");
        sortedList.display();
        
        System.out.println("=========================Sort==============================");
        sortedList.setSortStrategy(new QuickSort());
        sortedList.sort();
        sortedList.display();
        
        System.out.println("=========================Sort==============================");
 
        sortedList.setSortStrategy(new SelectionSort());
        sortedList.sort();
        sortedList.display();
    }
}
