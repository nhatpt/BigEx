package strategyPattern;

import java.util.ArrayList;
import java.util.List;

public class SortContext {
	private SortStrategy strategy;
    private List<String> items = new ArrayList<>();
     
    public void setSortStrategy(SortStrategy strategy) {
        this.strategy = strategy;
    }
 
    public void add(String name) {
        items.add(name);
    }
 
    public void sort() {
        strategy.sort(items);
    }
    
    public void display() {
    	for(String t : items) {
    		System.out.println(t);
    	}
    }
}
