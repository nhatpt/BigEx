package syn;

class counter{
	public void counterNumber() {
		 try {
			 for (int i = 0; i < 5; i++) {
					System.out.println("Counter: " + i);
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Thread  interrupted.");
		}
	}
}

class buildThread extends Thread{
	private Thread t;
	private String threadName;
	counter ct;
	buildThread(String name, counter _ct) {
		ct = _ct;
		this.threadName = name;
	}

	public void run() {
		synchronized(ct) {
			ct.counterNumber();
		}
		System.out.println("Thread " +  threadName + " exiting.");
	}
	
	public void start() {
		System.out.println("Thead " + threadName+ " started.");
		if(this.t == null){
			t = new Thread(this, threadName);
			t.start();
		}
	}
	
	public String getThreadName() {
		return this.threadName;
	}
	
}
class synchronizedThread{
	public static void main(String[] args){
		counter ct1 = new counter();
		buildThread t1 = new buildThread("Tada",  ct1);
		t1.start();
		buildThread t2 = new buildThread("Funny", ct1);
		t2.start();
		try {
			t1.join();
			t2.join();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Thread  interrupted.");
		}
	}
}
