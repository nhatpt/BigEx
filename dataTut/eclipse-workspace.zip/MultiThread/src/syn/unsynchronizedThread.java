package syn;

public class unsynchronizedThread extends Thread {
	Thread t;
	String threadName;
	public unsynchronizedThread(String name) {
		this.threadName = name;
		System.out.println("Thead " + threadName+ " created.");
	}
	
	public void run() {
		
		try {
			for (int i = 0; i < 5; i++) {
				System.out.println("Counter " + threadName +": " + i);
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Thread  interrupted.");
		}
		System.out.println("Thread " +  threadName + " exiting.");
	}
	
	public void start() {
		System.out.println("Thead " + threadName+ " started.");
		if(this.t == null)
		{
			t = new Thread(this, threadName);
			t.start();
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		unsynchronizedThread t1 = new unsynchronizedThread("Tada");
		unsynchronizedThread t2 = new unsynchronizedThread("Funny");
		t1.start();
		t2.start();
		try {
			t1.join();
			t2.join();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
