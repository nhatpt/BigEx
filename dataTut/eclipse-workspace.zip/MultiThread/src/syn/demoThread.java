package syn;

public class demoThread extends Thread{
	private Thread t;//Create a thread
	private String threadName;

	public demoThread(String name) {
		// TODO Auto-generated constructor stub
		threadName = name;
		System.out.println("Creating " + threadName + "...");
	}

	@Override
	public void run() {
		System.out.println("Running " + threadName + "...");
		// Work in there:
			try {
				for (int i = 7; i > 0; i--) {
					System.out.println("Thread " + threadName + ":" + i);
					Thread.sleep(1000);
					}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Thread " + threadName + " existing");
		}
		

	public void start() {
		System.out.println("Starting " + threadName);
		if (t == null) {
			t = new Thread(this, threadName);
			t.start();
		}
	}

	public static void main(String[] args) throws InterruptedException {
		demoThread de1 = new demoThread("Funny");
		de1.start();

		Thread.sleep(7000);
		demoThread de2 = new demoThread("Tada");
		de2.start();
	}

}
