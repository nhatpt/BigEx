package thread;

public class GetValueThread {
	private static int sum = 0;
	private static int count = 1;
	public synchronized static void sum() {
		sum+=count;
		count++;
	}
	
	public static void main(String[] args) {
		Thread t1 = new Thread( ()->{ 
			for (int i = 0; i < 10000; i++) {
				sum();
			}
		});
		
		Thread t2 = new Thread( ()->{ 
			for (int i = 0; i < 5000; i++) {
				sum();
			}
		});
		
		t1.start();
		t2.start();
		try {
			t1.join();
			t2.join();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println(sum);
	}
}
