package org.hibernate.HibernateDemo.queries;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.HibernateDemo.HibernateUtils;
import org.hibernate.HibernateDemo.entities.Employee;
import org.hibernate.query.Query;

public class QueryObjectDemo {
	public static void main(String[] args) {
		SessionFactory factory = HibernateUtils.getSessionFactory();
		Session session = factory.getCurrentSession();
		try {
			session.getTransaction().begin();

			 String sql = "Select e from "
	                   + Employee.class.getName() + " e" ;

			// Tạo đối tượng Query.
			Query<Employee> query = session.createQuery(sql);

			// Thực hiện truy vấn.
			List<Employee> employees = query.getResultList();

			for (Employee emp : employees) {
				System.out.println("Emp: "+ emp.getFirstName() + " : " + emp.getLastName()
						+ " : " + emp.getSalary());
			}
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			// Rollback trong trường hợp có lỗi xẩy ra.
			session.getTransaction().rollback();
		}
	}
}
